# Network-Security-Group-Automate

A script that helps you build OCI - Network Security Groups over OCI CLI. Uses an excel spreadsheet as input , and details of the spread sheet are converted to NSG.
